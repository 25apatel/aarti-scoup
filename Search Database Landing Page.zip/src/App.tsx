import { useState } from "react";
import { Home } from "./components/Home";
import { About } from "./components/About";
import { FacultyLogin } from "./components/FacultyLogin";
import { FacultySignup } from "./components/FacultySignup";
import { AdminLogin } from "./components/AdminLogin";
import { FacultyDashboard } from "./components/FacultyDashboard";
import { AdminDashboard } from "./components/AdminDashboard";

type Page =
  | "home"
  | "about"
  | "faculty-login"
  | "faculty-signup"
  | "admin-login";
type UserRole = "admin" | "faculty" | null;

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [userRole, setUserRole] = useState<UserRole>(null);

  const handleFacultyLoginSuccess = () => {
    setUserRole("faculty");
  };

  const handleAdminLoginSuccess = () => {
    setUserRole("admin");
  };

  const handleLogout = () => {
    setUserRole(null);
    setCurrentPage("home");
  };

  const handleSignupSuccess = () => {
    // After successful signup, redirect to login
    setCurrentPage("faculty-login");
  };

  // Show Admin Dashboard if logged in as admin
  if (userRole === "admin") {
    return <AdminDashboard onLogout={handleLogout} />;
  }

  // Show Faculty Dashboard if logged in as faculty
  if (userRole === "faculty") {
    return <FacultyDashboard onLogout={handleLogout} />;
  }

  // Show Admin Login page
  if (currentPage === "admin-login") {
    return (
      <AdminLogin
        onBack={() => setCurrentPage("home")}
        onLoginSuccess={handleAdminLoginSuccess}
      />
    );
  }

  // Show Faculty Login page
  if (currentPage === "faculty-login") {
    return (
      <FacultyLogin
        onBack={() => setCurrentPage("home")}
        onLoginSuccess={handleFacultyLoginSuccess}
        onSignup={() => setCurrentPage("faculty-signup")}
      />
    );
  }

  // Show Faculty Signup page
  if (currentPage === "faculty-signup") {
    return (
      <FacultySignup
        onBack={() => setCurrentPage("faculty-login")}
        onSignupSuccess={handleSignupSuccess}
      />
    );
  }

  // Show different pages
  return (
    <div className="min-h-screen bg-white">
      {currentPage === "home" && <Home onNavigate={setCurrentPage} />}
      {currentPage === "about" && <About onNavigate={setCurrentPage} />}
    </div>
  );
}