import { useState } from "react";
import { Button } from "./ui/button";
import { Search } from "lucide-react";
import { Navbar } from "./Navbar";
import { SearchResults } from "./SearchResults";
import { performSearch } from "../utils/searchEngine";
import { SearchResult } from "../data/searchData";
import salisburyLogo from "figma:asset/9cf64bd6e99483b928a4a848f39538439297b915.png";

interface HomeProps {
  onNavigate: (page: "home" | "about" | "faculty-login" | "admin-login") => void;
}

export function Home({ onNavigate }: HomeProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [activeFilters, setActiveFilters] = useState<string[]>(["faculty", "paper", "patent", "project"]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const results = performSearch(searchQuery);
    setSearchResults(results);
    setHasSearched(true);
  };

  const toggleFilter = (filter: string) => {
    setActiveFilters(prev => 
      prev.includes(filter) 
        ? prev.filter(f => f !== filter)
        : [...prev, filter]
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <Navbar onNavigate={onNavigate} currentPage="home" />

      {hasSearched ? (
        // Search Results View
        <div className="flex-1 bg-white">
          {/* Search Bar in Results */}
          <div className="bg-gradient-to-b from-[#fff9e6] to-white border-b border-gray-200 sticky top-0 z-10">
            <div className="max-w-6xl mx-auto px-6 py-6">
              <div className="flex justify-center mb-4">
                <form onSubmit={handleSearch} className="w-full max-w-2xl">
                  <div className="relative">
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search faculty expertise, research, or projects..."
                      className="w-full px-6 py-3 pr-14 text-base border-2 border-gray-300 rounded-full focus:outline-none focus:border-[#8b0000] focus:ring-4 focus:ring-[#ffd100]/30 transition-all shadow-md font-light bg-white"
                    />
                    <button
                      type="submit"
                      className="absolute right-2 top-1/2 -translate-y-1/2 bg-[#8b0000] hover:bg-[#6b0000] text-[#ffd100] p-2 rounded-full transition-colors shadow-md"
                    >
                      <Search className="w-5 h-5" />
                    </button>
                  </div>
                </form>
              </div>
              
              {/* Filters */}
              <div className="flex justify-center items-center gap-3 flex-wrap">
                <span className="text-sm text-gray-600 font-medium">Filter:</span>
                <button
                  onClick={() => toggleFilter("faculty")}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                    activeFilters.includes("faculty")
                      ? "bg-[#8b0000] text-[#ffd100]"
                      : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                  }`}
                >
                  Faculty
                </button>
                <button
                  onClick={() => toggleFilter("paper")}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                    activeFilters.includes("paper")
                      ? "bg-blue-600 text-white"
                      : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                  }`}
                >
                  Papers
                </button>
                <button
                  onClick={() => toggleFilter("patent")}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                    activeFilters.includes("patent")
                      ? "bg-purple-600 text-white"
                      : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                  }`}
                >
                  Patents
                </button>
                <button
                  onClick={() => toggleFilter("project")}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                    activeFilters.includes("project")
                      ? "bg-green-600 text-white"
                      : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                  }`}
                >
                  Projects
                </button>
              </div>
              
              <div className="flex justify-center mt-3">
                <button
                  onClick={() => {
                    setHasSearched(false);
                    setSearchQuery("");
                    setSearchResults([]);
                  }}
                  className="text-sm text-gray-600 hover:text-[#8b0000] transition-colors"
                >
                  ← Back to home
                </button>
              </div>
            </div>
          </div>
          <SearchResults results={searchResults} query={searchQuery} activeFilters={activeFilters} />
        </div>
      ) : (
        // Hero Section with Search
        <section className="flex items-center justify-center bg-gradient-to-b from-[#fff9e6] via-white to-gray-50 px-6 py-32 md:py-40 min-h-screen relative overflow-hidden">
          {/* Decorative background elements */}
          <div className="absolute top-20 right-10 w-64 h-64 bg-[#ffd100] rounded-full opacity-10 blur-3xl"></div>
          <div className="absolute bottom-20 left-10 w-96 h-96 bg-[#8b0000] rounded-full opacity-5 blur-3xl"></div>
          
          <div className="max-w-4xl w-full text-center space-y-8 relative z-10">
            {/* Heading */}
            <div className="space-y-5">
              <div className="inline-block mb-4">
                <span className="px-4 py-2 bg-[#8b0000] text-[#ffd100] text-sm font-medium rounded-full">
                  Salisbury University
                </span>
              </div>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-light text-gray-900 tracking-tight">
                Discover. <span className="text-[#8b0000]">Connect.</span> Collaborate.
              </h1>
              <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto font-light leading-relaxed">
                AI-powered platform connecting Salisbury University's expertise with real-world impact.
              </p>
            </div>

            {/* Search Bar */}
            <form onSubmit={handleSearch} className="w-full max-w-2xl mx-auto pt-6">
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search faculty expertise, research, or projects..."
                  className="w-full px-6 py-4 pr-14 text-base border-2 border-gray-300 rounded-full focus:outline-none focus:border-[#8b0000] focus:ring-4 focus:ring-[#ffd100]/30 transition-all shadow-lg font-light bg-white"
                />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-[#8b0000] hover:bg-[#6b0000] text-[#ffd100] p-3 rounded-full transition-colors shadow-md"
                >
                  <Search className="w-5 h-5" />
                </button>
              </div>
            </form>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-[#f5f5dc] border-t border-[#e5e5c5] mt-auto">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {/* Left - Branding */}
            <div>
              <div className="mb-4">
                <span className="text-xl font-bold text-gray-900">SCOUP</span>
              </div>
              <p className="text-sm text-gray-600 leading-relaxed mb-4">
                Salisbury University's centralized knowledge and collaboration platform. Connecting internal expertise with external opportunities to drive innovation.
              </p>
            </div>

            {/* Middle - Resources */}
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">Resources</h3>
              <ul className="space-y-3">
                <li>
                  <a href="#" className="text-gray-600 hover:text-[#8b0000] transition-colors text-sm">
                    Documentation
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-[#8b0000] transition-colors text-sm">
                    Tutorials
                  </a>
                </li>
              </ul>
            </div>

            {/* Right - About */}
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">About</h3>
              <ul className="space-y-3">
                <li>
                  <button
                    onClick={() => onNavigate("about")}
                    className="text-gray-600 hover:text-[#8b0000] transition-colors text-sm"
                  >
                    SCOUP Overview
                  </button>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-[#8b0000] transition-colors text-sm">
                    GitHub
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-[#8b0000] transition-colors text-sm">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Copyright */}
          <div className="flex flex-col md:flex-row justify-between items-center pt-8 mt-8 border-t border-[#e5e5c5]">
            <p className="text-sm text-gray-600">© 2025 SCOUP Team. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="text-sm text-gray-600 hover:text-[#8b0000] transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-sm text-gray-600 hover:text-[#8b0000] transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-sm text-gray-600 hover:text-[#8b0000] transition-colors">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}