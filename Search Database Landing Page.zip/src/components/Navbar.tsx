import { Button } from "./ui/button";
import { Menu, X } from "lucide-react";
import salisburyLogo from "figma:asset/9cf64bd6e99483b928a4a848f39538439297b915.png";

interface NavbarProps {
  onNavigate: (page: "home" | "about" | "faculty-login" | "admin-login") => void;
  currentPage: "home" | "about" | "faculty-login" | "admin-login";
}

export function Navbar({ onNavigate, currentPage }: NavbarProps) {
  return (
    <header className="border-b border-gray-200 bg-white">
      <div className="max-w-7xl mx-auto px-6 py-4">
        {/* Mobile menu checkbox - hidden but controls the menu */}
        <input type="checkbox" id="mobile-menu" className="peer hidden" />
        
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <button onClick={() => onNavigate("home")} className="flex-shrink-0">
            <img src={salisburyLogo} alt="Salisbury University" className="h-10" />
          </button>
          
          {/* Desktop Navigation - Hidden on mobile */}
          <nav className="hidden md:block">
            <button
              onClick={() => onNavigate("about")}
              className="text-gray-700 hover:text-[#8b0000] transition-colors"
            >
              About SCOUP
            </button>
          </nav>

          {/* Right Side - Desktop Buttons */}
          <div className="hidden md:flex items-center gap-3">
            <Button
              onClick={() => onNavigate("faculty-login")}
              variant="ghost"
              className="text-gray-900 hover:bg-[#ffd100] hover:text-[#8b0000] font-medium transition-colors border-0"
            >
              Faculty Login
            </Button>
            <Button
              onClick={() => onNavigate("admin-login")}
              variant="ghost"
              className="text-gray-900 hover:bg-[#ffd100] hover:text-[#8b0000] font-medium transition-colors border-0"
            >
              Admin Login
            </Button>
          </div>

          {/* Mobile Menu Toggle - Only visible on mobile */}
          <label htmlFor="mobile-menu" className="md:hidden cursor-pointer">
            <Menu className="w-6 h-6 text-gray-700 peer-checked:hidden" />
            <X className="w-6 h-6 text-gray-700 hidden peer-checked:block" />
          </label>
        </div>

        {/* Mobile Navigation - Controlled by checkbox */}
        <div className="md:hidden hidden peer-checked:block mt-4 pt-4 border-t border-gray-200 space-y-3">
          <button
            onClick={() => onNavigate("about")}
            className="block text-gray-700 hover:text-[#8b0000] transition-colors w-full text-left"
          >
            About SCOUP
          </button>
          <Button
            onClick={() => onNavigate("faculty-login")}
            variant="ghost"
            className="text-gray-900 hover:bg-[#ffd100] hover:text-[#8b0000] font-medium w-full"
          >
            Faculty Login
          </Button>
          <Button
            onClick={() => onNavigate("admin-login")}
            variant="ghost"
            className="text-gray-900 hover:bg-[#ffd100] hover:text-[#8b0000] font-medium w-full"
          >
            Admin Login
          </Button>
        </div>
      </div>
    </header>
  );
}