import { useState } from "react";
import { Search, Filter, MoreVertical, Eye, Edit, Trash2, CheckCircle, XCircle, Mail, User } from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";

interface FacultyMember {
  id: string;
  name: string;
  email: string;
  department: string;
  status: "active" | "pending" | "inactive";
  profileCompletion: number;
  publications: number;
  patents: number;
  projects: number;
  lastActive: string;
  joinDate: string;
}

export function FacultyManagementPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "pending" | "inactive">("all");
  const [selectedFaculty, setSelectedFaculty] = useState<FacultyMember | null>(null);

  const facultyMembers: FacultyMember[] = [
    {
      id: "1",
      name: "Dr. Sarah Chen",
      email: "schen@salisbury.edu",
      department: "Computer Science",
      status: "active",
      profileCompletion: 95,
      publications: 24,
      patents: 3,
      projects: 8,
      lastActive: "2 hours ago",
      joinDate: "Sep 2023",
    },
    {
      id: "2",
      name: "Dr. Michael Roberts",
      email: "mroberts@salisbury.edu",
      department: "Mathematics",
      status: "active",
      profileCompletion: 87,
      publications: 18,
      patents: 1,
      projects: 5,
      lastActive: "1 day ago",
      joinDate: "Jan 2024",
    },
    {
      id: "3",
      name: "Dr. Emily Thompson",
      email: "ethompson@salisbury.edu",
      department: "Computer Science",
      status: "pending",
      profileCompletion: 45,
      publications: 12,
      patents: 0,
      projects: 3,
      lastActive: "3 hours ago",
      joinDate: "Feb 2026",
    },
    {
      id: "4",
      name: "Dr. James Wilson",
      email: "jwilson@salisbury.edu",
      department: "Physics",
      status: "active",
      profileCompletion: 78,
      publications: 31,
      patents: 5,
      projects: 12,
      lastActive: "5 hours ago",
      joinDate: "Mar 2023",
    },
    {
      id: "5",
      name: "Dr. Lisa Anderson",
      email: "landerson@salisbury.edu",
      department: "Statistics",
      status: "active",
      profileCompletion: 92,
      publications: 22,
      patents: 2,
      projects: 7,
      lastActive: "1 hour ago",
      joinDate: "Aug 2024",
    },
    {
      id: "6",
      name: "Dr. David Kim",
      email: "dkim@salisbury.edu",
      department: "Engineering",
      status: "inactive",
      profileCompletion: 34,
      publications: 8,
      patents: 1,
      projects: 2,
      lastActive: "2 weeks ago",
      joinDate: "Dec 2022",
    },
  ];

  const filteredFaculty = facultyMembers.filter((faculty) => {
    const matchesSearch = 
      faculty.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faculty.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faculty.department.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filterStatus === "all" || faculty.status === filterStatus;

    return matchesSearch && matchesFilter;
  });

  const statusCounts = {
    all: facultyMembers.length,
    active: facultyMembers.filter(f => f.status === "active").length,
    pending: facultyMembers.filter(f => f.status === "pending").length,
    inactive: facultyMembers.filter(f => f.status === "inactive").length,
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-light text-gray-900 mb-2">Faculty Management</h1>
          <p className="text-gray-600 font-light">
            Manage faculty profiles and monitor activity
          </p>
        </div>
        <Button className="bg-[#8b0000] hover:bg-[#6b0000] text-white">
          <User className="w-4 h-4 mr-2" />
          Add Faculty
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <button
          onClick={() => setFilterStatus("all")}
          className={`p-4 rounded-lg border-2 transition-all text-left ${
            filterStatus === "all" 
              ? "border-[#8b0000] bg-[#8b0000]/5" 
              : "border-gray-200 hover:border-gray-300"
          }`}
        >
          <div className="text-sm text-gray-600 mb-1">Total Faculty</div>
          <div className="text-3xl font-light text-gray-900">{statusCounts.all}</div>
        </button>
        <button
          onClick={() => setFilterStatus("active")}
          className={`p-4 rounded-lg border-2 transition-all text-left ${
            filterStatus === "active" 
              ? "border-green-600 bg-green-50" 
              : "border-gray-200 hover:border-gray-300"
          }`}
        >
          <div className="text-sm text-gray-600 mb-1">Active</div>
          <div className="text-3xl font-light text-green-600">{statusCounts.active}</div>
        </button>
        <button
          onClick={() => setFilterStatus("pending")}
          className={`p-4 rounded-lg border-2 transition-all text-left ${
            filterStatus === "pending" 
              ? "border-yellow-600 bg-yellow-50" 
              : "border-gray-200 hover:border-gray-300"
          }`}
        >
          <div className="text-sm text-gray-600 mb-1">Pending</div>
          <div className="text-3xl font-light text-yellow-600">{statusCounts.pending}</div>
        </button>
        <button
          onClick={() => setFilterStatus("inactive")}
          className={`p-4 rounded-lg border-2 transition-all text-left ${
            filterStatus === "inactive" 
              ? "border-gray-600 bg-gray-50" 
              : "border-gray-200 hover:border-gray-300"
          }`}
        >
          <div className="text-sm text-gray-600 mb-1">Inactive</div>
          <div className="text-3xl font-light text-gray-600">{statusCounts.inactive}</div>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Search by name, email, or department..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-11"
            />
          </div>
          <Button variant="outline" className="border-gray-300">
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
        </div>
      </div>

      {/* Faculty Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-700">Faculty Member</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-700">Department</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-700">Status</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-700">Profile</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-700">Content</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-700">Last Active</th>
                <th className="text-right px-6 py-4 text-sm font-medium text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredFaculty.map((faculty) => (
                <tr key={faculty.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div>
                      <div className="font-medium text-gray-900">{faculty.name}</div>
                      <div className="text-sm text-gray-600">{faculty.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{faculty.department}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${
                      faculty.status === "active" 
                        ? "bg-green-100 text-green-700" 
                        : faculty.status === "pending"
                        ? "bg-yellow-100 text-yellow-700"
                        : "bg-gray-100 text-gray-700"
                    }`}>
                      {faculty.status === "active" && <CheckCircle className="w-3 h-3" />}
                      {faculty.status === "pending" && <XCircle className="w-3 h-3" />}
                      {faculty.status.charAt(0).toUpperCase() + faculty.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="flex-1">
                        <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${
                              faculty.profileCompletion >= 80 
                                ? "bg-green-600" 
                                : faculty.profileCompletion >= 50 
                                ? "bg-yellow-600" 
                                : "bg-red-600"
                            }`}
                            style={{ width: `${faculty.profileCompletion}%` }}
                          />
                        </div>
                      </div>
                      <span className="text-xs text-gray-600 w-10">{faculty.profileCompletion}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-3 text-xs text-gray-600">
                      <span>{faculty.publications}p</span>
                      <span>{faculty.patents}pt</span>
                      <span>{faculty.projects}pr</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-600">{faculty.lastActive}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-2">
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <Eye className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <Mail className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <Edit className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <MoreVertical className="w-4 h-4 text-gray-600" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredFaculty.length === 0 && (
          <div className="text-center py-12">
            <User className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-600">No faculty members found</p>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="bg-gradient-to-r from-[#8b0000] to-[#6b0000] rounded-lg p-6 text-white">
        <h3 className="font-medium text-lg mb-4">Quick Actions</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
            Approve Pending Profiles ({statusCounts.pending})
          </Button>
          <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
            Send Reminder Emails
          </Button>
          <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
            Export Faculty List
          </Button>
        </div>
      </div>
    </div>
  );
}
