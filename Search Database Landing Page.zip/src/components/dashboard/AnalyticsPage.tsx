import { useState } from "react";
import { Eye, TrendingUp, Building2, Award, Users, Search, ArrowUp, ArrowDown } from "lucide-react";

export function AnalyticsPage() {
  // Mock data for analytics
  const profileViews = {
    total: 1247,
    thisMonth: 183,
    percentChange: 24,
    trend: "up" as const,
    viewsOverTime: [
      { month: "Aug", views: 98 },
      { month: "Sep", views: 142 },
      { month: "Oct", views: 156 },
      { month: "Nov", views: 168 },
      { month: "Dec", views: 147 },
      { month: "Jan", views: 183 },
    ],
  };

  const searchKeywords = [
    { keyword: "machine learning", count: 234, trend: "up" },
    { keyword: "data science", count: 189, trend: "up" },
    { keyword: "artificial intelligence", count: 156, trend: "stable" },
    { keyword: "neural networks", count: 123, trend: "up" },
    { keyword: "computer vision", count: 98, trend: "down" },
    { keyword: "natural language processing", count: 87, trend: "up" },
    { keyword: "deep learning", count: 76, trend: "stable" },
    { keyword: "predictive analytics", count: 54, trend: "up" },
  ];

  const industryInterest = [
    { industry: "Technology & Software", percentage: 32, count: 156 },
    { industry: "Healthcare & Pharmaceuticals", percentage: 24, count: 117 },
    { industry: "Financial Services", percentage: 18, count: 88 },
    { industry: "Manufacturing", percentage: 12, count: 58 },
    { industry: "Education & Research", percentage: 8, count: 39 },
    { industry: "Government & Defense", percentage: 6, count: 29 },
  ];

  const engagementMetrics = [
    { label: "Contact Requests", value: 47, change: 12, icon: Users },
    { label: "Profile Shares", value: 23, change: -3, icon: TrendingUp },
    { label: "Document Downloads", value: 156, change: 28, icon: Search },
    { label: "Collaboration Inquiries", value: 19, change: 8, icon: Award },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-light text-gray-900 mb-2">Analytics Dashboard</h1>
        <p className="text-gray-600 font-light">
          Track your profile performance and discover who's finding your research
        </p>
      </div>

      {/* Engagement Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {engagementMetrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <div key={metric.label} className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 bg-[#8b0000]/10 rounded-lg flex items-center justify-center">
                  <Icon className="w-5 h-5 text-[#8b0000]" />
                </div>
                <div className={`flex items-center gap-1 text-sm ${metric.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {metric.change >= 0 ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
                  <span>{Math.abs(metric.change)}%</span>
                </div>
              </div>
              <div className="text-3xl font-light text-gray-900 mb-1">{metric.value}</div>
              <div className="text-sm text-gray-600">{metric.label}</div>
            </div>
          );
        })}
      </div>

      {/* Profile Views */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-[#8b0000] rounded-lg flex items-center justify-center">
            <Eye className="w-5 h-5 text-[#ffd100]" />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-medium text-gray-900">Profile Views</h2>
            <p className="text-sm text-gray-600">Track how many people are viewing your profile</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-light text-gray-900">{profileViews.thisMonth}</div>
            <div className="text-sm text-gray-600">this month</div>
            <div className="flex items-center gap-1 text-green-600 text-sm mt-1">
              <ArrowUp className="w-4 h-4" />
              <span>{profileViews.percentChange}% vs last month</span>
            </div>
          </div>
        </div>

        {/* Simple Bar Chart */}
        <div className="space-y-3">
          <div className="flex items-end justify-between gap-2 h-40">
            {profileViews.viewsOverTime.map((data, index) => {
              const maxViews = Math.max(...profileViews.viewsOverTime.map(d => d.views));
              const heightPercent = (data.views / maxViews) * 100;
              return (
                <div key={data.month} className="flex-1 flex flex-col items-center gap-2">
                  <div className="text-xs text-gray-600 font-medium">{data.views}</div>
                  <div 
                    className="w-full bg-gradient-to-t from-[#8b0000] to-[#8b0000]/70 rounded-t transition-all hover:from-[#6b0000] hover:to-[#6b0000]/70"
                    style={{ height: `${heightPercent}%` }}
                  />
                  <div className="text-xs text-gray-600">{data.month}</div>
                </div>
              );
            })}
          </div>
          <div className="pt-4 border-t border-gray-200 flex justify-between text-sm">
            <span className="text-gray-600">Total Profile Views</span>
            <span className="font-medium text-gray-900">{profileViews.total.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Search Keywords */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-[#8b0000] rounded-lg flex items-center justify-center">
            <Search className="w-5 h-5 text-[#ffd100]" />
          </div>
          <div>
            <h2 className="text-xl font-medium text-gray-900">Top Search Keywords</h2>
            <p className="text-sm text-gray-600">Keywords that lead people to your profile</p>
          </div>
        </div>

        <div className="space-y-3">
          {searchKeywords.map((keyword, index) => {
            const maxCount = searchKeywords[0].count;
            const widthPercent = (keyword.count / maxCount) * 100;
            return (
              <div key={keyword.keyword} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400 font-medium w-6">{index + 1}</span>
                    <span className="text-gray-900 font-medium">{keyword.keyword}</span>
                    {keyword.trend === "up" && (
                      <ArrowUp className="w-3 h-3 text-green-600" />
                    )}
                    {keyword.trend === "down" && (
                      <ArrowDown className="w-3 h-3 text-red-600" />
                    )}
                  </div>
                  <span className="text-gray-600">{keyword.count} searches</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-[#8b0000] to-[#ffd100] h-full rounded-full transition-all duration-500"
                    style={{ width: `${widthPercent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Industry Interest */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-[#8b0000] rounded-lg flex items-center justify-center">
            <Building2 className="w-5 h-5 text-[#ffd100]" />
          </div>
          <div>
            <h2 className="text-xl font-medium text-gray-900">Industry Interest</h2>
            <p className="text-sm text-gray-600">Which industries are searching for your expertise</p>
          </div>
        </div>

        <div className="space-y-4">
          {industryInterest.map((industry) => (
            <div key={industry.industry} className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-900 font-medium">{industry.industry}</span>
                <div className="flex items-center gap-3">
                  <span className="text-gray-600">{industry.count} views</span>
                  <span className="text-[#8b0000] font-medium">{industry.percentage}%</span>
                </div>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-[#8b0000] to-[#8b0000]/70 h-full rounded-full transition-all duration-500"
                  style={{ width: `${industry.percentage}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <div className="text-sm text-gray-600 mb-1">Most Active Industry</div>
              <div className="text-lg font-medium text-gray-900">{industryInterest[0].industry}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-1">Total Industry Views</div>
              <div className="text-lg font-medium text-gray-900">
                {industryInterest.reduce((sum, ind) => sum + ind.count, 0)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Insights & Recommendations */}
      <div className="bg-gradient-to-r from-[#8b0000] to-[#6b0000] rounded-lg p-6 text-white">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-[#ffd100] rounded-lg flex items-center justify-center flex-shrink-0">
            <TrendingUp className="w-5 h-5 text-[#8b0000]" />
          </div>
          <div>
            <h3 className="font-medium text-lg mb-2">Key Insights</h3>
            <ul className="space-y-2 text-sm text-white/90">
              <li>• Your profile views increased by 24% this month - great momentum!</li>
              <li>• "Machine learning" and "data science" are your top-performing keywords</li>
              <li>• Technology & Software sector shows the highest interest in your work</li>
              <li>• Consider adding more content related to "neural networks" - it's trending up</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
