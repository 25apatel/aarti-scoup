import { useState } from "react";
import { FileText, TrendingUp, Award, Target, BookOpen, ArrowUp, ArrowDown, ExternalLink } from "lucide-react";

export function CitationTrackerPage() {
  // Mock citation data
  const overallStats = {
    totalCitations: 1847,
    hIndex: 18,
    i10Index: 24,
    citationsThisYear: 342,
    yearOverYearGrowth: 23,
  };

  const topPapers = [
    {
      id: 1,
      title: "Deep Learning Approaches for Natural Language Processing",
      journal: "Journal of Machine Learning Research",
      year: 2021,
      citations: 487,
      recentCitations: 124,
      trend: "up",
      growthRate: 34,
      citationsOverTime: [45, 67, 89, 112, 143, 174, 204, 256, 312, 389, 442, 487],
    },
    {
      id: 2,
      title: "Convolutional Neural Networks for Image Classification",
      journal: "IEEE Transactions on Pattern Analysis",
      year: 2020,
      citations: 356,
      recentCitations: 89,
      trend: "up",
      growthRate: 28,
      citationsOverTime: [23, 45, 78, 98, 124, 156, 189, 223, 254, 289, 321, 356],
    },
    {
      id: 3,
      title: "Transfer Learning in Computer Vision Applications",
      journal: "Computer Vision and Image Understanding",
      year: 2022,
      citations: 243,
      recentCitations: 98,
      trend: "up",
      growthRate: 67,
      citationsOverTime: [12, 34, 56, 78, 102, 134, 167, 198, 243],
    },
    {
      id: 4,
      title: "Attention Mechanisms in Neural Machine Translation",
      journal: "Computational Linguistics",
      year: 2019,
      citations: 198,
      recentCitations: 34,
      trend: "stable",
      growthRate: 5,
      citationsOverTime: [34, 56, 78, 98, 112, 134, 156, 167, 178, 187, 193, 198],
    },
    {
      id: 5,
      title: "Reinforcement Learning for Autonomous Systems",
      journal: "Artificial Intelligence",
      year: 2023,
      citations: 87,
      recentCitations: 67,
      trend: "up",
      growthRate: 156,
      citationsOverTime: [5, 23, 47, 87],
    },
  ];

  const citationMetrics = [
    {
      label: "Total Citations",
      value: overallStats.totalCitations.toLocaleString(),
      subtext: "All-time",
      icon: Award,
      color: "from-[#8b0000] to-[#6b0000]",
    },
    {
      label: "h-index",
      value: overallStats.hIndex,
      subtext: "Research impact",
      icon: Target,
      color: "from-[#8b0000] to-[#6b0000]",
    },
    {
      label: "i10-index",
      value: overallStats.i10Index,
      subtext: "Highly cited papers",
      icon: BookOpen,
      color: "from-[#8b0000] to-[#6b0000]",
    },
    {
      label: "This Year",
      value: overallStats.citationsThisYear,
      subtext: `+${overallStats.yearOverYearGrowth}% vs last year`,
      icon: TrendingUp,
      color: "from-[#8b0000] to-[#6b0000]",
    },
  ];

  const [selectedPaper, setSelectedPaper] = useState(topPapers[0]);

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-light text-gray-900 mb-2">Citation Impact Tracker</h1>
        <p className="text-gray-600 font-light">
          Monitor your research impact and track citation metrics over time
        </p>
      </div>

      {/* Overall Citation Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {citationMetrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <div key={metric.label} className="bg-white rounded-lg border border-gray-200 p-6 relative overflow-hidden">
              <div className="relative z-10">
                <div className="w-10 h-10 bg-[#8b0000]/10 rounded-lg flex items-center justify-center mb-3">
                  <Icon className="w-5 h-5 text-[#8b0000]" />
                </div>
                <div className="text-3xl font-light text-gray-900 mb-1">{metric.value}</div>
                <div className="text-sm font-medium text-gray-900 mb-1">{metric.label}</div>
                <div className="text-xs text-gray-600">{metric.subtext}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Top Cited Papers */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-[#8b0000] rounded-lg flex items-center justify-center">
            <FileText className="w-5 h-5 text-[#ffd100]" />
          </div>
          <div>
            <h2 className="text-xl font-medium text-gray-900">Top Cited Papers</h2>
            <p className="text-sm text-gray-600">Your most impactful research publications</p>
          </div>
        </div>

        <div className="space-y-4">
          {topPapers.map((paper, index) => (
            <div 
              key={paper.id} 
              className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                selectedPaper.id === paper.id 
                  ? 'border-[#8b0000] bg-[#8b0000]/5' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => setSelectedPaper(paper)}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-[#8b0000]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-medium text-[#8b0000]">#{index + 1}</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900 mb-1">{paper.title}</h3>
                      <p className="text-sm text-gray-600 mb-2">
                        {paper.journal} • {paper.year}
                      </p>
                      <div className="flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-1">
                          <Award className="w-4 h-4 text-[#8b0000]" />
                          <span className="font-medium text-gray-900">{paper.citations}</span>
                          <span className="text-gray-600">total citations</span>
                        </div>
                        <div className={`flex items-center gap-1 ${
                          paper.trend === 'up' ? 'text-green-600' : 'text-gray-600'
                        }`}>
                          {paper.trend === 'up' ? (
                            <ArrowUp className="w-4 h-4" />
                          ) : (
                            <ArrowDown className="w-4 h-4" />
                          )}
                          <span className="font-medium">{paper.recentCitations}</span>
                          <span>last 6 months</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                    paper.growthRate > 50 
                      ? 'bg-green-100 text-green-700' 
                      : paper.growthRate > 20 
                      ? 'bg-blue-100 text-blue-700' 
                      : 'bg-gray-100 text-gray-700'
                  }`}>
                    <TrendingUp className="w-3 h-3" />
                    +{paper.growthRate}%
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Selected Paper Detail */}
      {selectedPaper && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-xl font-medium text-gray-900 mb-2">{selectedPaper.title}</h2>
              <p className="text-sm text-gray-600">{selectedPaper.journal} • {selectedPaper.year}</p>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-[#8b0000] text-[#ffd100] rounded-lg hover:bg-[#6b0000] transition-colors">
              <ExternalLink className="w-4 h-4" />
              View Paper
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-gradient-to-br from-[#8b0000] to-[#6b0000] rounded-lg p-4 text-white">
              <div className="text-sm opacity-90 mb-1">Total Citations</div>
              <div className="text-3xl font-light">{selectedPaper.citations}</div>
            </div>
            <div className="bg-gradient-to-br from-[#ffd100] to-[#e6bc00] rounded-lg p-4">
              <div className="text-sm text-gray-700 mb-1">Recent Citations</div>
              <div className="text-3xl font-light text-gray-900">{selectedPaper.recentCitations}</div>
              <div className="text-xs text-gray-700 mt-1">Last 6 months</div>
            </div>
            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <div className="text-sm text-green-700 mb-1">Growth Rate</div>
              <div className="text-3xl font-light text-green-700">+{selectedPaper.growthRate}%</div>
              <div className="text-xs text-green-600 mt-1">Year over year</div>
            </div>
          </div>

          {/* Citation Timeline */}
          <div>
            <h3 className="font-medium text-gray-900 mb-4">Citation Timeline</h3>
            <div className="flex items-end justify-between gap-1 h-48 bg-gray-50 rounded-lg p-4">
              {selectedPaper.citationsOverTime.map((count, index) => {
                const maxCitations = Math.max(...selectedPaper.citationsOverTime);
                const heightPercent = (count / maxCitations) * 100;
                const year = selectedPaper.year;
                const monthsSincePublication = selectedPaper.citationsOverTime.length;
                const isRecent = index >= monthsSincePublication - 3;
                
                return (
                  <div key={index} className="flex-1 flex flex-col items-center gap-2 group">
                    <div className="text-xs text-gray-600 font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                      {count}
                    </div>
                    <div 
                      className={`w-full rounded-t transition-all ${
                        isRecent 
                          ? 'bg-gradient-to-t from-[#ffd100] to-[#e6bc00]' 
                          : 'bg-gradient-to-t from-[#8b0000] to-[#8b0000]/70'
                      } hover:opacity-80`}
                      style={{ height: `${heightPercent}%` }}
                    />
                  </div>
                );
              })}
            </div>
            <div className="flex justify-between mt-2 text-xs text-gray-600 px-4">
              <span>{selectedPaper.year}</span>
              <span>Present</span>
            </div>
          </div>
        </div>
      )}

      {/* Citation Insights */}
      <div className="bg-gradient-to-r from-[#8b0000] to-[#6b0000] rounded-lg p-6 text-white">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-[#ffd100] rounded-lg flex items-center justify-center flex-shrink-0">
            <TrendingUp className="w-5 h-5 text-[#8b0000]" />
          </div>
          <div>
            <h3 className="font-medium text-lg mb-2">Citation Insights</h3>
            <ul className="space-y-2 text-sm text-white/90">
              <li>• Your h-index of {overallStats.hIndex} indicates strong research impact</li>
              <li>• Citations increased {overallStats.yearOverYearGrowth}% this year - excellent growth!</li>
              <li>• "{topPapers[0].title}" is your most cited work with {topPapers[0].citations} citations</li>
              <li>• Recent papers are gaining traction quickly - your 2023 publication has {topPapers[4].growthRate}% growth rate</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
