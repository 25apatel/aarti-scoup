import { useState, useEffect, useRef } from "react";
import { Users, Network, Award, FileText, Building2, TrendingUp } from "lucide-react";

interface Node {
  id: string;
  name: string;
  type: "self" | "colleague" | "external";
  department?: string;
  collaborations: number;
  x: number;
  y: number;
  vx?: number;
  vy?: number;
}

interface Link {
  source: string;
  target: string;
  strength: number;
  type: "paper" | "project" | "patent";
}

export function NetworkPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hoveredNode, setHoveredNode] = useState<Node | null>(null);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);

  // Mock network data
  const nodes: Node[] = [
    // Self (center)
    { id: "self", name: "You", type: "self", department: "Computer Science", collaborations: 12, x: 400, y: 300, vx: 0, vy: 0 },
    
    // Close collaborators
    { id: "1", name: "Dr. Sarah Chen", type: "colleague", department: "Computer Science", collaborations: 8, x: 300, y: 200, vx: 0, vy: 0 },
    { id: "2", name: "Dr. Michael Roberts", type: "colleague", department: "Mathematics", collaborations: 6, x: 500, y: 200, vx: 0, vy: 0 },
    { id: "3", name: "Dr. Emily Thompson", type: "colleague", department: "Computer Science", collaborations: 5, x: 250, y: 350, vx: 0, vy: 0 },
    
    // Secondary collaborators
    { id: "4", name: "Dr. James Wilson", type: "colleague", department: "Physics", collaborations: 3, x: 550, y: 350, vx: 0, vy: 0 },
    { id: "5", name: "Dr. Lisa Anderson", type: "colleague", department: "Statistics", collaborations: 4, x: 350, y: 450, vx: 0, vy: 0 },
    { id: "6", name: "Dr. David Kim", type: "colleague", department: "Engineering", collaborations: 3, x: 450, y: 450, vx: 0, vy: 0 },
    
    // External collaborators
    { id: "7", name: "Dr. Maria Garcia", type: "external", department: "MIT", collaborations: 2, x: 200, y: 250, vx: 0, vy: 0 },
    { id: "8", name: "Dr. Robert Johnson", type: "external", department: "Stanford", collaborations: 2, x: 600, y: 250, vx: 0, vy: 0 },
    { id: "9", name: "Dr. Jennifer Lee", type: "external", department: "Harvard", collaborations: 1, x: 150, y: 400, vx: 0, vy: 0 },
  ];

  const links: Link[] = [
    { source: "self", target: "1", strength: 8, type: "paper" },
    { source: "self", target: "2", strength: 6, type: "project" },
    { source: "self", target: "3", strength: 5, type: "paper" },
    { source: "self", target: "4", strength: 3, type: "patent" },
    { source: "self", target: "5", strength: 4, type: "paper" },
    { source: "self", target: "6", strength: 3, type: "project" },
    { source: "self", target: "7", strength: 2, type: "paper" },
    { source: "self", target: "8", strength: 2, type: "paper" },
    { source: "1", target: "3", strength: 3, type: "paper" },
    { source: "1", target: "7", strength: 1, type: "paper" },
    { source: "2", target: "4", strength: 2, type: "project" },
    { source: "5", target: "6", strength: 2, type: "paper" },
    { source: "3", target: "9", strength: 1, type: "paper" },
  ];

  const networkStats = {
    totalCollaborators: nodes.length - 1,
    internalCollaborators: nodes.filter(n => n.type === "colleague").length,
    externalCollaborators: nodes.filter(n => n.type === "external").length,
    departments: [...new Set(nodes.filter(n => n.type === "colleague").map(n => n.department))].length,
    strongConnections: links.filter(l => l.strength >= 5).length,
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Simple physics simulation
    const simulate = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw links
      links.forEach(link => {
        const sourceNode = nodes.find(n => n.id === link.source);
        const targetNode = nodes.find(n => n.id === link.target);
        if (!sourceNode || !targetNode) return;

        ctx.beginPath();
        ctx.moveTo(sourceNode.x, sourceNode.y);
        ctx.lineTo(targetNode.x, targetNode.y);
        
        // Line color based on connection strength
        const alpha = 0.1 + (link.strength / 10) * 0.4;
        ctx.strokeStyle = `rgba(139, 0, 0, ${alpha})`;
        ctx.lineWidth = 1 + (link.strength / 10) * 3;
        ctx.stroke();
      });

      // Draw nodes
      nodes.forEach(node => {
        const isHovered = hoveredNode?.id === node.id;
        const isSelected = selectedNode?.id === node.id;
        
        // Node size based on collaborations
        const baseRadius = node.type === "self" ? 20 : 12;
        const radius = baseRadius + (node.collaborations / 2);

        // Node color
        let color = "#8b0000";
        if (node.type === "self") {
          color = "#8b0000";
        } else if (node.type === "colleague") {
          color = "#ffd100";
        } else {
          color = "#999999";
        }

        // Draw node
        ctx.beginPath();
        ctx.arc(node.x, node.y, radius, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();

        // Draw border for self, hovered, or selected
        if (node.type === "self" || isHovered || isSelected) {
          ctx.strokeStyle = "#8b0000";
          ctx.lineWidth = 3;
          ctx.stroke();
        }

        // Draw label
        if (node.type === "self" || isHovered || isSelected) {
          ctx.fillStyle = "#1f2937";
          ctx.font = node.type === "self" ? "bold 14px sans-serif" : "12px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(node.name, node.x, node.y - radius - 8);
        }
      });
    };

    // Apply simple forces for layout
    const applyForces = () => {
      const centerX = width / 2;
      const centerY = height / 2;
      
      nodes.forEach(node => {
        if (node.type === "self") return;

        // Gravity towards center
        const dx = centerX - node.x;
        const dy = centerY - node.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (!node.vx) node.vx = 0;
        if (!node.vy) node.vy = 0;

        node.vx += dx * 0.001;
        node.vy += dy * 0.001;

        // Repulsion from other nodes
        nodes.forEach(other => {
          if (other.id === node.id) return;
          const odx = node.x - other.x;
          const ody = node.y - other.y;
          const odist = Math.sqrt(odx * odx + ody * ody);
          if (odist < 100 && odist > 0) {
            node.vx += (odx / odist) * 2;
            node.vy += (ody / odist) * 2;
          }
        });

        // Damping
        node.vx *= 0.9;
        node.vy *= 0.9;

        // Update position
        node.x += node.vx;
        node.y += node.vy;

        // Keep within bounds
        node.x = Math.max(50, Math.min(width - 50, node.x));
        node.y = Math.max(50, Math.min(height - 50, node.y));
      });
    };

    const animate = () => {
      applyForces();
      simulate();
      requestAnimationFrame(animate);
    };

    animate();
  }, [hoveredNode, selectedNode]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const clickedNode = nodes.find(node => {
      const dx = x - node.x;
      const dy = y - node.y;
      const radius = (node.type === "self" ? 20 : 12) + (node.collaborations / 2);
      return Math.sqrt(dx * dx + dy * dy) <= radius;
    });

    setSelectedNode(clickedNode || null);
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const hoveredNode = nodes.find(node => {
      const dx = x - node.x;
      const dy = y - node.y;
      const radius = (node.type === "self" ? 20 : 12) + (node.collaborations / 2);
      return Math.sqrt(dx * dx + dy * dy) <= radius;
    });

    setHoveredNode(hoveredNode || null);
    canvas.style.cursor = hoveredNode ? "pointer" : "default";
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-light text-gray-900 mb-2">Collaboration Network</h1>
        <p className="text-gray-600 font-light">
          Visualize your research connections and collaboration patterns
        </p>
      </div>

      {/* Network Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="w-10 h-10 bg-[#8b0000]/10 rounded-lg flex items-center justify-center mb-3">
            <Users className="w-5 h-5 text-[#8b0000]" />
          </div>
          <div className="text-3xl font-light text-gray-900 mb-1">{networkStats.totalCollaborators}</div>
          <div className="text-sm text-gray-600">Total Collaborators</div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="w-10 h-10 bg-[#ffd100]/20 rounded-lg flex items-center justify-center mb-3">
            <Building2 className="w-5 h-5 text-[#8b0000]" />
          </div>
          <div className="text-3xl font-light text-gray-900 mb-1">{networkStats.internalCollaborators}</div>
          <div className="text-sm text-gray-600">Internal (SU)</div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center mb-3">
            <Network className="w-5 h-5 text-gray-600" />
          </div>
          <div className="text-3xl font-light text-gray-900 mb-1">{networkStats.externalCollaborators}</div>
          <div className="text-sm text-gray-600">External</div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="w-10 h-10 bg-[#8b0000]/10 rounded-lg flex items-center justify-center mb-3">
            <Award className="w-5 h-5 text-[#8b0000]" />
          </div>
          <div className="text-3xl font-light text-gray-900 mb-1">{networkStats.departments}</div>
          <div className="text-sm text-gray-600">Departments</div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mb-3">
            <TrendingUp className="w-5 h-5 text-green-600" />
          </div>
          <div className="text-3xl font-light text-gray-900 mb-1">{networkStats.strongConnections}</div>
          <div className="text-sm text-gray-600">Strong Connections</div>
        </div>
      </div>

      {/* Network Visualization */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#8b0000] rounded-lg flex items-center justify-center">
              <Network className="w-5 h-5 text-[#ffd100]" />
            </div>
            <div>
              <h2 className="text-xl font-medium text-gray-900">Network Visualization</h2>
              <p className="text-sm text-gray-600">Interactive map of your collaboration network</p>
            </div>
          </div>

          {/* Legend */}
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 bg-[#8b0000] rounded-full"></div>
              <span className="text-gray-600">You</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 bg-[#ffd100] rounded-full"></div>
              <span className="text-gray-600">SU Faculty</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 bg-gray-400 rounded-full"></div>
              <span className="text-gray-600">External</span>
            </div>
          </div>
        </div>

        <canvas
          ref={canvasRef}
          width={800}
          height={600}
          onClick={handleCanvasClick}
          onMouseMove={handleCanvasMouseMove}
          className="w-full border border-gray-200 rounded-lg bg-gray-50"
        />

        <p className="text-xs text-gray-500 mt-4 text-center">
          Node size represents number of collaborations. Line thickness represents collaboration strength. Click on nodes for details.
        </p>
      </div>

      {/* Selected Node Details */}
      {selectedNode && selectedNode.type !== "self" && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-xl font-medium text-gray-900">{selectedNode.name}</h3>
              <p className="text-sm text-gray-600">{selectedNode.department}</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-xs font-medium ${
              selectedNode.type === "colleague" 
                ? "bg-[#ffd100]/20 text-[#8b0000]" 
                : "bg-gray-100 text-gray-700"
            }`}>
              {selectedNode.type === "colleague" ? "Internal" : "External"}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-6 mb-6">
            <div>
              <div className="text-sm text-gray-600 mb-1">Collaborations</div>
              <div className="text-2xl font-light text-gray-900">{selectedNode.collaborations}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-1">Co-authored Papers</div>
              <div className="text-2xl font-light text-gray-900">
                {links.filter(l => 
                  (l.source === "self" && l.target === selectedNode.id || 
                   l.target === "self" && l.source === selectedNode.id) && 
                  l.type === "paper"
                ).length}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-1">Joint Projects</div>
              <div className="text-2xl font-light text-gray-900">
                {links.filter(l => 
                  (l.source === "self" && l.target === selectedNode.id || 
                   l.target === "self" && l.source === selectedNode.id) && 
                  l.type === "project"
                ).length}
              </div>
            </div>
          </div>

          <button className="w-full px-4 py-2 bg-[#8b0000] text-[#ffd100] rounded-lg hover:bg-[#6b0000] transition-colors">
            View Full Profile
          </button>
        </div>
      )}

      {/* Top Collaborators List */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-[#8b0000] rounded-lg flex items-center justify-center">
            <Users className="w-5 h-5 text-[#ffd100]" />
          </div>
          <div>
            <h2 className="text-xl font-medium text-gray-900">Top Collaborators</h2>
            <p className="text-sm text-gray-600">Your most frequent research partners</p>
          </div>
        </div>

        <div className="space-y-3">
          {nodes
            .filter(n => n.type !== "self")
            .sort((a, b) => b.collaborations - a.collaborations)
            .slice(0, 5)
            .map((node, index) => (
              <div 
                key={node.id}
                className="flex items-center justify-between p-4 rounded-lg border border-gray-200 hover:border-[#8b0000] transition-colors cursor-pointer"
                onClick={() => setSelectedNode(node)}
              >
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 bg-[#8b0000]/10 rounded-lg flex items-center justify-center">
                    <span className="text-sm font-medium text-[#8b0000]">#{index + 1}</span>
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">{node.name}</div>
                    <div className="text-sm text-gray-600">{node.department}</div>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <div className="text-sm text-gray-600">Collaborations</div>
                    <div className="text-lg font-medium text-[#8b0000]">{node.collaborations}</div>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                    node.type === "colleague" 
                      ? "bg-[#ffd100]/20 text-[#8b0000]" 
                      : "bg-gray-100 text-gray-700"
                  }`}>
                    {node.type === "colleague" ? "Internal" : "External"}
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Insights */}
      <div className="bg-gradient-to-r from-[#8b0000] to-[#6b0000] rounded-lg p-6 text-white">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-[#ffd100] rounded-lg flex items-center justify-center flex-shrink-0">
            <TrendingUp className="w-5 h-5 text-[#8b0000]" />
          </div>
          <div>
            <h3 className="font-medium text-lg mb-2">Network Insights</h3>
            <ul className="space-y-2 text-sm text-white/90">
              <li>• You collaborate with faculty across {networkStats.departments} different departments</li>
              <li>• {Math.round((networkStats.internalCollaborators / networkStats.totalCollaborators) * 100)}% of your collaborations are with SU faculty</li>
              <li>• Dr. Sarah Chen is your top collaborator with 8 joint projects</li>
              <li>• Your network spans both internal and external institutions, fostering diverse research</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
