export interface FacultyMember {
  id: string;
  name: string;
  title: string;
  department: string;
  email: string;
  phone: string;
  photo: string;
  bio: string;
  researchInterests: string[];
  aiKeywords: string[];
}

export interface Paper {
  id: string;
  title: string;
  authors: string[];
  year: number;
  abstract: string;
  link: string;
  aiKeywords: string[];
}

export interface Patent {
  id: string;
  title: string;
  inventors: string[];
  patentNumber: string;
  year: number;
  description: string;
  link: string;
  aiKeywords: string[];
}

export interface Project {
  id: string;
  title: string;
  leadFaculty: string[];
  status: string;
  description: string;
  startDate: string;
  endDate?: string;
  aiKeywords: string[];
}

export interface SearchResult {
  type: "faculty" | "paper" | "patent" | "project";
  data: FacultyMember | Paper | Patent | Project;
  confidence: number;
  aiJustification: string;
  matchedKeywords: string[];
}

// Mock Faculty Data
export const facultyData: FacultyMember[] = [
  {
    id: "1",
    name: "Dr. Sarah Johnson",
    title: "Professor of Computer Science",
    department: "Computer Science",
    email: "sjohnson@salisbury.edu",
    phone: "(410) 543-6000",
    photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop",
    bio: "Dr. Johnson specializes in artificial intelligence and machine learning with a focus on natural language processing and deep learning applications.",
    researchInterests: ["Artificial Intelligence", "Machine Learning", "Natural Language Processing", "Deep Learning"],
    aiKeywords: ["AI", "ML", "NLP", "neural networks", "deep learning", "natural language", "machine learning", "artificial intelligence", "data science", "neural nets"]
  },
  {
    id: "2",
    name: "Dr. Michael Chen",
    title: "Associate Professor of Environmental Science",
    department: "Environmental Studies",
    email: "mchen@salisbury.edu",
    phone: "(410) 543-6100",
    photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop",
    bio: "Dr. Chen's research focuses on climate change impacts on coastal ecosystems and sustainable environmental management practices.",
    researchInterests: ["Climate Change", "Coastal Ecosystems", "Environmental Sustainability", "Marine Biology"],
    aiKeywords: ["climate change", "coastal ecosystems", "sustainability", "environment", "marine biology", "conservation", "ecology", "carbon emissions", "sea level rise", "wetlands"]
  },
  {
    id: "3",
    name: "Dr. Emily Rodriguez",
    title: "Professor of Business Analytics",
    department: "Business Administration",
    email: "erodriguez@salisbury.edu",
    phone: "(410) 543-6200",
    photo: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop",
    bio: "Dr. Rodriguez specializes in business intelligence, predictive analytics, and data-driven decision making for organizational strategy.",
    researchInterests: ["Business Analytics", "Data Science", "Predictive Modeling", "Strategic Management"],
    aiKeywords: ["business analytics", "data science", "predictive analytics", "business intelligence", "big data", "statistics", "forecasting", "decision making", "data visualization", "analytics"]
  },
  {
    id: "4",
    name: "Dr. James Patterson",
    title: "Associate Professor of Physics",
    department: "Physics",
    email: "jpatterson@salisbury.edu",
    phone: "(410) 543-6300",
    photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop",
    bio: "Dr. Patterson conducts research in quantum mechanics, photonics, and optical materials with applications in computing and communications.",
    researchInterests: ["Quantum Mechanics", "Photonics", "Optical Materials", "Quantum Computing"],
    aiKeywords: ["quantum mechanics", "photonics", "optics", "quantum computing", "laser physics", "quantum information", "optical materials", "quantum systems", "physics", "quantum"]
  }
];

// Mock Papers Data
export const papersData: Paper[] = [
  {
    id: "1",
    title: "Deep Learning Approaches to Natural Language Understanding in Healthcare",
    authors: ["Dr. Sarah Johnson", "Dr. Mark Williams"],
    year: 2024,
    abstract: "This paper explores novel deep learning architectures for improving natural language understanding in clinical settings, with applications to automated diagnosis and patient record analysis.",
    link: "https://example.com/paper1",
    aiKeywords: ["deep learning", "natural language", "healthcare", "NLP", "clinical", "diagnosis", "medical AI", "machine learning", "neural networks", "AI in medicine"]
  },
  {
    id: "2",
    title: "Climate Change Impacts on Chesapeake Bay Wetland Ecosystems",
    authors: ["Dr. Michael Chen", "Dr. Lisa Thompson"],
    year: 2023,
    abstract: "An in-depth study analyzing the effects of rising sea levels and temperature changes on wetland biodiversity in the Chesapeake Bay region over a 20-year period.",
    link: "https://example.com/paper2",
    aiKeywords: ["climate change", "wetlands", "Chesapeake Bay", "biodiversity", "sea level rise", "coastal ecology", "environmental science", "conservation", "marine ecosystems", "sustainability"]
  },
  {
    id: "3",
    title: "Predictive Analytics for Supply Chain Optimization in E-Commerce",
    authors: ["Dr. Emily Rodriguez", "Dr. Robert Kim"],
    year: 2024,
    abstract: "This research presents a machine learning framework for optimizing supply chain operations in e-commerce platforms, reducing costs by up to 30% through predictive modeling.",
    link: "https://example.com/paper3",
    aiKeywords: ["predictive analytics", "supply chain", "e-commerce", "machine learning", "optimization", "business analytics", "logistics", "data science", "forecasting", "operations"]
  },
  {
    id: "4",
    title: "Quantum Entanglement in Photonic Crystal Systems",
    authors: ["Dr. James Patterson", "Dr. Angela Martinez"],
    year: 2023,
    abstract: "Experimental investigation of quantum entanglement phenomena in engineered photonic crystal structures with implications for quantum communication and computing.",
    link: "https://example.com/paper4",
    aiKeywords: ["quantum entanglement", "photonics", "quantum computing", "quantum mechanics", "optical systems", "quantum communication", "physics", "quantum information", "photonic crystals", "quantum systems"]
  }
];

// Mock Patents Data
export const patentsData: Patent[] = [
  {
    id: "1",
    title: "AI-Powered Medical Diagnosis System Using Natural Language Processing",
    inventors: ["Dr. Sarah Johnson"],
    patentNumber: "US-2024-1234567",
    year: 2024,
    description: "An intelligent system that uses advanced NLP algorithms to analyze patient symptoms and medical histories to assist healthcare providers in making accurate diagnoses.",
    link: "https://patents.google.com/patent1",
    aiKeywords: ["AI", "medical diagnosis", "NLP", "healthcare technology", "natural language processing", "machine learning", "clinical decision support", "medical AI", "diagnosis", "healthcare"]
  },
  {
    id: "2",
    title: "Sustainable Coastal Erosion Prevention System",
    inventors: ["Dr. Michael Chen", "Dr. Lisa Thompson"],
    patentNumber: "US-2023-9876543",
    year: 2023,
    description: "An eco-friendly coastal protection system using bio-engineered materials to prevent erosion while maintaining marine ecosystem health.",
    link: "https://patents.google.com/patent2",
    aiKeywords: ["coastal erosion", "sustainability", "environmental engineering", "marine ecosystems", "conservation", "green technology", "coastal protection", "ecology", "environmental science", "erosion prevention"]
  },
  {
    id: "3",
    title: "Real-Time Business Analytics Platform with Predictive Modeling",
    inventors: ["Dr. Emily Rodriguez"],
    patentNumber: "US-2024-5555555",
    year: 2024,
    description: "A cloud-based platform that provides real-time business analytics with integrated predictive modeling capabilities for strategic decision-making.",
    link: "https://patents.google.com/patent3",
    aiKeywords: ["business analytics", "predictive modeling", "real-time analytics", "cloud computing", "business intelligence", "data analytics", "decision support", "forecasting", "analytics platform", "data science"]
  }
];

// Mock Projects Data
export const projectsData: Project[] = [
  {
    id: "1",
    title: "AI-Enhanced Learning Platform for STEM Education",
    leadFaculty: ["Dr. Sarah Johnson", "Dr. Robert Davis"],
    status: "Active",
    description: "Developing an intelligent tutoring system that uses machine learning to personalize STEM education and adapt to individual student learning patterns.",
    startDate: "2023-09-01",
    endDate: "2025-08-31",
    aiKeywords: ["AI", "education", "STEM", "machine learning", "personalized learning", "intelligent tutoring", "educational technology", "adaptive learning", "e-learning", "EdTech"]
  },
  {
    id: "2",
    title: "Chesapeake Bay Climate Resilience Initiative",
    leadFaculty: ["Dr. Michael Chen"],
    status: "Active",
    description: "Multi-year project studying climate change impacts on the Chesapeake Bay ecosystem and developing strategies for coastal community resilience.",
    startDate: "2022-06-01",
    endDate: "2026-05-31",
    aiKeywords: ["climate change", "Chesapeake Bay", "resilience", "coastal communities", "environmental science", "sustainability", "climate adaptation", "marine ecosystems", "conservation", "climate research"]
  },
  {
    id: "3",
    title: "Small Business Analytics Consulting Program",
    leadFaculty: ["Dr. Emily Rodriguez"],
    status: "Active",
    description: "Partnership with local businesses to provide data analytics consulting services while giving students hands-on experience in business intelligence.",
    startDate: "2024-01-01",
    aiKeywords: ["business analytics", "consulting", "small business", "data science", "business intelligence", "analytics", "entrepreneurship", "data-driven decisions", "business strategy", "local business"]
  },
  {
    id: "4",
    title: "Quantum Computing Research Lab Development",
    leadFaculty: ["Dr. James Patterson"],
    status: "Planning",
    description: "Establishing a quantum computing research facility to explore quantum algorithms and their applications in cryptography and optimization.",
    startDate: "2024-09-01",
    endDate: "2027-08-31",
    aiKeywords: ["quantum computing", "quantum algorithms", "cryptography", "quantum research", "physics", "quantum mechanics", "quantum systems", "computing", "research lab", "quantum technology"]
  }
];
